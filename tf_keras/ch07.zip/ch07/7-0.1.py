grades = [1, 2, 3, 30, 31, 32, 33, 34]            # 每次數學考試的分數
basic = grades[0]                   # 先將第 1 次成績做為基準分
min_delta = 10                      # 要比基準分進步 10 分以上
patience = 3

for index in range(1, len(grades)):
    if grades[index] < basic + min_delta:  # 判斷這次考試分數是否比基準分還高 10 分
        patience -= 1   # 容忍度下降 1
    else:
        basic = grades[index]
        patience = 3    # 爸媽很開心, 容忍度復原
    if patience == 0:   # 忍無可忍！
        print(f'在第 {index+1} 次考試後, 被打屁股！')
        break


# ---- 這個程式也可以 ---- #
# for index in range(1, len(grades)):
#     grade = grades[index]
#     print(f'第 {index+1} 次數學成績: {grade}')
#     if grade < basic + min_delta:  # 判斷這次考試分數是否比基準分還高 10 分
#         w = '進步' if grade - basic >= 0 else '退步'
#         patience -= 1
#         print(f'比基準分{w} {abs(grade - basic)} 分, 目前容忍度: {patience} ！')
#     else:
#         print(f'比基準分進步 {grade - basic} 分, 獎勵, 容忍度復原 (3)！')
#         print(f'●將基準分設定為: {grade} 分')
#         basic = grade
#         patience = 3    # 爸媽很開心, 容忍度復原
#     if patience == 0:   # 忍無可忍！
#         print('打屁股！')
#         break