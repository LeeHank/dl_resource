grades = [5, 10, 15, 20, 10, 30, 80, 20, 50]    # 每次數學考試的分數
basic = grades[0]                   # 先將第 1 次成績做為基準分
min_delta = 10                      # 要比基準分進步 10 分以上

for index in range(1, len(grades)):
    if grades[index] < basic + min_delta:  # 判斷這次考試分數是否比基準分還高 10 分
        print(f'第 {index+1} 考試未達進步標準')
    else:
        print(f'第 {index+1} 考試達進步標準, 得到獎勵！')
        basic = grades[index]


# ---- 用此程式也可以 ---- #
# for index in range(1, len(grades)):
#     grade = grades[index]
#     print(f'第 {index+1} 次數學成績: {grade}')
#     if grade < basic + min_delta:  # 判斷這次考試分數是否比基準分還高 10 分
#         w = '進步' if grade - basic >= 0 else '退步'
#         print(f'比基準分{w} {abs(grade - basic)} 分, 懲罰！')
#     else:
#         print(f'比基準分進步 {grade - basic} 分, 獎勵！')
#         print(f'●將基準分設定為: {grade} 分')
#         basic = grade
