from PIL import Image
import matplotlib.pyplot as plt

img=Image.open('cat_dog/train/cat/cat.1.jpg')
img.show()  #←會啟動 Windows 預設的看圖程式來顯示圖檔

plt.imshow(img)
#plt.show()