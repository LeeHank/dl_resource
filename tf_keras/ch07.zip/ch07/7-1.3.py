# 載入 IMDB 資料集並進行序列對齊
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences

(train_data, train_labels),(test_data, test_labels) = imdb.load_data(num_words=10000)  #←只處理常見的前 10000 個單字

maxlen = 500    #←設定序列長度為 500
train_data = pad_sequences(train_data, maxlen=maxlen, truncating='post')
test_data = pad_sequences(test_data, maxlen=maxlen, truncating='post')    #←只取前 500 個單字, 超過的截掉

# 建立模型
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers

model = Sequential()
model.add(layers.Embedding(10000, 16, input_length=maxlen))
model.add(layers.Flatten())  #←將嵌入層的輸出展平
model.add(layers.Dense(1, activation='sigmoid'))
model.summary()

# 編譯模型
model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              metrics=['acc'])

# ---- 建立 TensorBoard Callback 物件 ---- #
from tensorflow.keras.callbacks import TensorBoard

tensorboard = TensorBoard(log_dir='my_log', 
                          histogram_freq=0, 
                          write_images=True,
                          embeddings_freq=1,
                          )

history = model.fit(train_data, train_labels,
                    epochs=10,
                    batch_size=512,
                    validation_split=0.2,
                    callbacks=[ tensorboard ])




