from tensorflow.keras import Input, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, concatenate

ipt = Input(shape=(10,10,200))
print(ipt.shape)  # (None, 224, 224, 64)

ka, kb, kc, kd = 64, (64,128), (16,32), 32    # 設定輸出通道數 (卷積核數量)
a = Conv2D(ka, kernel_size=1, padding='same', activation='relu')(ipt) # 分支 a

b1 = Conv2D(kb[0], kernel_size=1, padding='same', activation='relu')(ipt) # 分支 b
b2 = Conv2D(kb[1], kernel_size=3, padding='same', activation='relu')(b1) # 分支 b

c1 = Conv2D(kc[0], kernel_size=1, padding='same', activation='relu')(ipt) # 分支 c
c2 = Conv2D(kc[1], kernel_size=5, padding='same', activation='relu')(c1) # 分支 c


d1 = MaxPooling2D(pool_size=3, strides=1, padding='same')(ipt)         # 分支 d
d2 = Conv2D(kd, kernel_size=1, padding='same', activation='relu')(d1) # 分支 d

print(a.shape)  # (None, 10, 10, 64), 輸出通道數維持不變
print(b2.shape)  # (None, 10, 10, 128), 輸出通道數維持不變
print(c2.shape)  # (None, 10, 10, 32), 輸出通道數維持不變
print(d2.shape)  # (None, 10, 10, 32), 分支 d 的輸出通道數從 200 降為 32


output = concatenate([a, b2, c2, d2], axis=-1) # 串接 4 個分支的輸出
print(output.shape) # (None, 10, 10, 256)

model = Model(ipt, output)
model.summary()








