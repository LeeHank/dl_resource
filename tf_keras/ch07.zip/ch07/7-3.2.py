from tensorflow.keras.applications import VGG16

vgg16 = VGG16()

vgg16.summary()


# ---- 可以使用 plot_model 繪製模型結構圖 ---- #

# from tensorflow.keras.utils import plot_model
# import os

# # os.environ["PATH"] += os.pathsep + 'D:\Graphviz2.38\\bin'
# plot_model(vgg16, show_shapes=True)

