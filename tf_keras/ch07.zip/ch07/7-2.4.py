from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.datasets import mnist

(train_images, train_labels), (_, _) = mnist.load_data()

gobj = ImageDataGenerator(rescale=1./255) #←設定要將圖檔的每一個像素值都乘以 1./255

gen = gobj.flow(               #↓必須轉為 4D 陣列 (最後一軸為 channel, 灰階圖的值為 1)
    train_images.reshape(-1, 28, 28, 1), #←輸入的樣本
    train_labels,                        #←輸入的標籤
    batch_size=10)                       #←批次量

data, label = gen.next()   #←讀取一批次的資料
print(f'第 0 批次樣本的 shape: {data.shape}, 標籤的 shpae: {label.shape}')
print(f'第 0 張圖第 6 橫排的像素值：{data[0].reshape(28,28)[6].round(2)}')
print(f'10 個標籤值為 {label}')

