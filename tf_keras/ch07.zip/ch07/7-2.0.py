from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt

img1 = image.load_img('cat_dog/train/cat/cat.1.jpg')  #←讀取圖檔內容
img2 = image.load_img('cat_dog/train/dog/dog.1.jpg')  #←讀取圖檔內容

plt.figure(1)     #←建立新畫框
plt.imshow(img1)  #←繪製圖片
plt.figure(2)     #←建立新畫框
plt.imshow(img2)  #←繪製圖片
plt.show()        #←實際顯示圖片

x1 = image.img_to_array(img1)  #} 將 PIL 影像資料轉為 NumPy 陣列
x2 = image.img_to_array(img2)  #}
print('x1.shape = ', x1.shape) #} 顯示 NumPy 陣列的 shape
print('x2.shape = ', x2.shape) #}
