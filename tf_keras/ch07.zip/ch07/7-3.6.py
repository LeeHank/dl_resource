'''示範 Batch Normalization 的使用方式'''
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, BatchNormalization, Activation

model = Sequential() 
model.add(Conv2D(filters=32, 
                 kernel_size=3,
                # activation='sigmoid',      # 因為要將 BN 層加在卷積層與啟動函數之間, 所以不使用此參數
                input_shape=(32, 32, 3)))  					
model.add(BatchNormalization())
model.add(Activation('sigmoid'))   # 在這裡才使用 ReLU 啟動函數

model.summary()
