# -- 載入 cifar10 資料集 -- #
from tensorflow.keras.datasets import cifar10

(x_train, y_train), (x_test, y_test) = cifar10.load_data()  

# -- 查看圖片與標籤的 shape -- #
print('x_train shape:', x_train.shape)
print('x_test shape:', x_test.shape)
print('y_train shape:', y_train.shape)
print('y_test shape:', y_test.shape)
print(y_train[0: 10])   # 查看前 10 個訓練標籤

# -- 進行 min-max normalization -- #
# min-max normalization 前
print(x_train[0][0][0])

# 進行 min-max normalization...
x_train_norm = x_train.astype('float32') / 255	# 每個像素值除以 255
x_test_norm = x_test.astype('float32') / 255  	# 每個像素值除以 255

# min-max normalization 後
print(x_train_norm[0][0][0])
                        # 每個像素值除以 255


# -- 對標籤進行 One-hot 編碼 -- #


# 轉換前
print(y_train[0])

# 進行 One-hot 編碼轉換...
from tensorflow.keras import utils
y_train_onehot = utils.to_categorical(y_train, 10) # 將訓練標籤進行 One-hot 編碼
y_test_onehot = utils.to_categorical(y_test, 10)	 # 將測試標籤進行 One-hot 編碼

# 轉換後
print(y_train_onehot[0])

# -- CNN 神經網路架構 -- #

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten
from tensorflow.keras.layers import Conv2D, MaxPooling2D, SeparableConv2D

cnn = Sequential() 
cnn.add(SeparableConv2D(32, (3, 3), activation='relu', padding='same', 
                input_shape=(32, 32, 3)))  					# 卷積層 (輸入)
cnn.add(Dropout(0.25))           							# Dropout 
cnn.add(MaxPooling2D((2, 2)))                        			# 池化層

cnn.add(SeparableConv2D(64, (3, 3), padding='same', activation='relu'))   	# 卷積層
cnn.add(Dropout(0.25))                              			# Dropout 層
cnn.add(MaxPooling2D((2, 2)))                             		# 池化層

cnn.add(Flatten())                                    			# 展平層
cnn.add(Dropout(0.25))                                   		# Dropout 
cnn.add(Dense(1024, activation='relu'))                      	# 密集層
cnn.add(Dropout(0.25))                                     	# Dropout 
cnn.add(Dense(10, activation='softmax'))                    		# 密集層 (輸出分類) 


# -- 神經網路的訓練配置 -- #
cnn.compile(loss='categorical_crossentropy',	# 損失函數
              optimizer='adam',				    # adam優化器
              metrics=['acc'])			    # 以準確度做為訓練指標


# -- 進行訓練 -- #
history = cnn.fit(x=x_train_norm,   	# 訓練資料
	  		    y=y_train_onehot,		# 訓練標籤
      		    batch_size=128,		# 每個批次用 128 筆資料進行訓練
      		    epochs=20,			# 20 個訓練週期 (次數)
      		    validation_split = 0.1, 	# 拿出訓練資料的 10% 做為驗證資料
			    )
predict_prop = cnn.predict(x_test_norm)
print(predict_prop[0])

# --  繪製圖表 -- # 
import util7 as u    	# 匯入自訂的繪圖工具模組

u.plot( history.history,   # 繪製準確率與驗證準確度的歷史線圖
        ('acc', 'val_acc'),
        'Training & Vaildation Acc',
        ('Epoch','Acc'), 
        )     

u.plot( history.history,   #  繪製損失及驗證損失的歷史線圖
        ('loss', 'val_loss'),
        'Training & Vaildation Loss',
        ('Epoch','Loss'), 
        )

