from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.models import Sequential

#建立 CNN 模型
model = Sequential()
model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(150,150,3)))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(128, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(128, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Flatten())
model.add(Dense(512, activation='relu'))
model.add(Dense(1, activation='sigmoid')) #}
                                          #}二元分類
model.compile(loss='binary_crossentropy', #}
              optimizer='RMSprop',
              metrics=['acc'])

###生成資料訓練模型
from tensorflow.keras.preprocessing.image import ImageDataGenerator

gobj = ImageDataGenerator(rescale=1./255, validation_split=0.25,
    rotation_range=40,      #←隨機旋轉 -40~40 度
    width_shift_range=0.2,  #←隨機向左或右平移 20% 寬度以內的像素
    height_shift_range=0.2, #←隨機向上或下平移 20% 高度以內的像素
    shear_range=10,         #←隨機順時針傾斜影像 0~10 度
    zoom_range=0.2,         #←隨機水平或垂直縮放影像 20% (80%~120%)
    horizontal_flip=True)   #←隨機水平翻轉影像

trn_gen = gobj.flow_from_directory( #←建立生成訓練資料的走訪器
    'cat_dog/train',         #←指定目標資料夾
    target_size=(150, 150),  #←調整所有影像大小成 150x150
    batch_size=50,           #←每批次要生成多少筆資料
    class_mode='binary',     #←指定分類方式, 這裡是設為二元分類
    subset='training')       #←只生成前 75% 的訓練資料

gobj = ImageDataGenerator(rescale=1./255, validation_split=0.25) #←另建一個無擴增功能的 gobj 來生成驗證資料

val_gen = gobj.flow_from_directory(#←建立生成驗證資料的走訪器
    'cat_dog/train',         #←指定目標資料夾
    target_size=(150, 150),  #←調整所有影像大小成 150x150
    batch_size=50,           #←每批次要生成多少筆資料
    class_mode='binary',     #←指定分類方式, 這裡是設為二元分類
    subset='validation')     #←只生成後 25% 的驗證資料

history = model.fit(trn_gen,        #←指定訓練用的走訪器
                   steps_per_epoch=120,  #←設定每週期從訓練走訪器抽取 120 批次 (=6000/50)
                    epochs=30, verbose=2,
                    validation_data=val_gen, #←指定驗證用的走訪器
                   validation_steps=40) #←設定每週期從驗證走訪器抽取 40 批次 (=2000/50)

import util7 as u

u.plot(history.history, ('loss','val_loss'),  # 繪製損失值歷史線圖
       'Training & Validation loss', ('Epochs', 'Loss'))

u.plot(history.history, ('acc','val_acc'),    # 繪製準確度歷史線圖
       'Training & Validation accuracy', ('Epochs', 'Accuracy'))


###評估及預測
gobj = ImageDataGenerator(rescale=1./255)

eva_gen = gobj.flow_from_directory( #←建立生成評估資料的走訪器
    'cat_dog/test',          #←指定要讀取測試資料夾
    target_size=(150, 150),
    batch_size=50,
    class_mode='binary')

loss, acc = model.evaluate(eva_gen, steps=40)      #←評估 40 批次 (=2000/50)
print('評估的準確率：', acc)

pre_gen = gobj.flow_from_directory( #←建立生成預測資料的走訪器
    'cat_dog/test',          #←指定要讀取測試資料夾
    target_size=(150, 150),
    batch_size=10,           #←每批次 10 筆
    class_mode=None)         #←預測時不需要標籤

ans = model.predict(pre_gen, steps=1)  #←用 1 批次 (10筆) 的資料來預測
print('預測的結果：', ans.round(1))     #←顯示預測結果
