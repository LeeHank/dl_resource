from tensorflow.keras import Input, Model
from tensorflow.keras.layers import SeparableConv2D, Conv2D

ipt = Input(shape=(30,30,200))
opt = SeparableConv2D(64, kernel_size=3, use_bias=False, strides=2, padding='same')(ipt)  # 進行深度可分離卷積
model = Model(ipt, opt)
model.summary()
