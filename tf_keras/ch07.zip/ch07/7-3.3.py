from tensorflow.keras import Input, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, concatenate

ipt = Input(shape=(10,10,200))
print(ipt.shape)  # (None, 224, 224, 64)

ka, kb, kc = 64, 128, 32    # 設定輸出通道數 (卷積核數量)
a = Conv2D(ka, kernel_size=1, padding='same', activation='relu')(ipt) # 分支 a
b = Conv2D(kb, kernel_size=3, padding='same', activation='relu')(ipt) # 分支 b
c = Conv2D(kc, kernel_size=5, padding='same', activation='relu')(ipt) # 分支 c
d = MaxPooling2D(pool_size=3, strides=1, padding='same')(ipt)         # 分支 d

print(a.shape)  # (None, 10, 10, 64), 輸出通道數維持不變
print(b.shape)  # (None, 10, 10, 128), 輸出通道數維持不變
print(c.shape)  # (None, 10, 10, 32), 輸出通道數維持不變
print(d.shape)  # (None, 10, 10, 200), 分支 d 的輸出通道數從 200 降為 32

opt = concatenate([a, b, c, d], axis=-1) # 串接 4 個分支的輸出

print(opt.shape) # (None, 224, 224, 416)


model = Model(ipt, opt)
model.summary()