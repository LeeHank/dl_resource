# 載入 MNIST 資料集
from tensorflow.keras.datasets import mnist

(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

# 預處理訓練資料
x_train = train_images.reshape((60000, 28 * 28)) #←將 (60000,28,28) 轉換成 (60000,784)
x_train = x_train.astype('float32') / 255     #←再將 0~255 的像素值轉換成 0~1 的浮點數

x_test = test_images.reshape((10000, 28 * 28))  #}←將 10000 筆測試樣本做同樣的轉換
x_test = x_test.astype('float32') / 255          #}

# 預處理標籤資料
from tensorflow.keras.utils import to_categorical

y_train = to_categorical(train_labels)  #←將標籤做 One-hot 編碼
y_test  = to_categorical(test_labels)  #←將測試做 One-hot 編碼

#程 建立多元分類模型
from tensorflow.keras.models import Sequential  #← 匯入 Keras 的序列式模型類別
from tensorflow.keras.layers import Dense, Activation, BatchNormalization       #← 匯入 Keras 的密集層類別

model = Sequential()            #← 建立序列模型物件
model.add(Dense(512, activation='relu', input_dim= 784)) #← 輸入

# ---- 新加入的層 ---- #
for _ in range(40):
    model.add(Dense(128))               # 加入密集層
    model.add(BatchNormalization())     # 在 Dense 層與 ReLU 啟動函數之間加上 BN 層
    model.add(Activation('sigmoid'))       # 使用 Sigmoid 做為啟動函數
# ---- 新加入的層 ---- #

model.add(Dense(10, activation='softmax'))              #← 分類層
model.compile(optimizer='rmsprop',                      #← 指定優化器
              loss='categorical_crossentropy',          #← 指定損失函數
              metrics=['acc'])                          #← 指定評量準則

#程 訓練模型
history = model.fit(x_train, y_train, epochs=5, 
                    validation_split=0.3,
                    batch_size=128)

# --  繪製圖表 -- # 
import util7 as u    	# 匯入自訂的繪圖工具模組

u.plot( history.history,   # 繪製準確率與驗證準確度的歷史線圖
        ('acc', 'val_acc'),
        'Training & Vaildation Acc',
        ('Epoch','Acc'), 
        )     

u.plot( history.history,   #  繪製損失及驗證損失的歷史線圖
        ('loss', 'val_loss'),
        'Training & Vaildation Loss',
        ('Epoch','Loss'), 
        )