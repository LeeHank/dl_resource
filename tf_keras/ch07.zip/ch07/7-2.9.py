from tensorflow.keras.layers import Conv2D,MaxPooling2D,Flatten,Dense,Dropout
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np

def to_EMA(points, a=0.3):  #←將歷史資料中的數值轉為 EMA 值
  ret = []          # 儲存轉換結果的串列
  EMA = points[0]   # 第 0 個 EMA 值
  for pt in points:
    EMA = pt*a + EMA*(1-a)  # 本期EMA = 本期值*0.3 + 前期EMA * 0.7
    ret.append(EMA)         # 將本期EMA加入串列中
  return ret

def test(drop=0.0):
    #建立 CNN 模型
    model = Sequential()
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(150,150,3)))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(128, (3, 3), activation='relu'))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(128, (3, 3), activation='relu'))
    model.add(MaxPooling2D((2, 2)))
    model.add(Flatten())
    if drop: model.add(Dropout(drop)) #←在展平層後加 Dropout 層
    model.add(Dense(512, activation='relu'))
    model.add(Dense(1, activation='sigmoid')) #}
                                              #}二元分類
    model.compile(loss='binary_crossentropy', #}
                  optimizer='RMSprop',
                  metrics=['acc'])

    ###生成資料訓練模型
    gobj = ImageDataGenerator(rescale=1./255, validation_split=0.75) #←只用 25% 做訓練

    trn_gen = gobj.flow_from_directory( #←建立生成訓練資料的走訪器
        'cat_dog/train',         #←指定目標資料夾
        target_size=(150, 150),  #←調整所有影像大小成 150x150
        batch_size=50,        #←每批次要生成多少筆資料
        class_mode='binary',     #←指定分類方式, 這裡是設為二元分類
        subset='training')       #←只生成前 25% 的訓練資料

    gobj = ImageDataGenerator(rescale=1./255)

    val_gen = gobj.flow_from_directory( #←建立生成驗證資料的走訪器
        'cat_dog/test',          #←指定要讀取測試資料夾
        target_size=(150, 150),
        batch_size=50,
        class_mode='binary')

    history = model.fit(trn_gen,        #←指定訓練用的走訪器
                        epochs=100, verbose=2,
                        validation_data=val_gen) #←指定驗證用的走訪器

    hv = to_EMA(history.history['val_acc'])  # 將 val_acc 歷史資料的值轉成 EMA 值
    idx = np.argmax(hv) #←找出最佳驗證週期
    acc = hv[idx]       #←取得最佳驗證的 val_mae 值
    print(f'使用 Dropout={drop} 的 EMA 最佳週期為 {idx+1}, 驗證準確率為 {acc}')

    import util7 as u

    u.plot(history.history, ('loss','val_loss'),  # 繪製損失值歷史線圖
           'Training & Validation loss', ('Epochs', 'Loss'))

    history.history['ema_acc'] = hv
    u.plot(history.history, ('acc','val_acc', 'ema_acc'),    # 繪製準確度歷史線圖
           'Training & Validation accuracy', ('Epochs', 'Accuracy'))

## 主程式：以不同的丟棄率呼叫 test() 做測試
for drop in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99]:
    test(drop)

