from tensorflow.keras.preprocessing.image import ImageDataGenerator

gobj = ImageDataGenerator(
    rescale=1./255,
    rotation_range=40,      #←隨機旋轉 -40~40 度
    width_shift_range=0.2,  #←隨機向左或右平移 20% 寬度的像素
    height_shift_range=0.2, #←隨機向上或下平移 20% 高度的像素
    shear_range=10,         #←隨機順時針傾斜影像 10 度
    zoom_range=0.2,         #←隨機水平及(或)垂直縮放影像 20%
    horizontal_flip=True)   #←隨機水平翻轉影像

from tensorflow.keras.preprocessing import image
import util7 as u    #←匯入包含自訂函式的模組

img = image.load_img('cat_dog/train/dog/dog.68.jpg')  #←讀取圖檔
img = image.img_to_array(img)        #←轉為 NumPy 陣列
img = img.reshape((1,) + img.shape)  #←將 shape 改為 (1, 圖寬, 圖高, 3)

def show(gobj):   #← 建立可由 gobj 讀取 5 張擴增影像並顯示出來的函式
    gen = gobj.flow(img)   #←用前面讀取的圖檔做為影像來源
    imgs = [img[0]/255.0]  #←先將原始影像加入串列中 (並將像素縮放到 0~1)
    for i in range(4):              #}讀取 4 張擴增的影像並加到串列中
        imgs.append(next(gen)[0])   #}
    u.plot_img(imgs, grid=(1, 5), size=(20,4))  #←顯示串列中的影像

show(gobj)  #←執行函式以顯示原始影像及 4 張擴增影像

gobj = ImageDataGenerator(rescale=1./255,
                          rotation_range=60)      #←隨機旋轉 -60~60 度
show(gobj)

gobj = ImageDataGenerator(rescale=1./255,
                          width_shift_range=0.2,  #←隨機向左或右平移 20% 寬度的像素
                          height_shift_range=60)  #←隨機向上或下平移 60 像素
show(gobj)

gobj = ImageDataGenerator(rescale=1./255,
                          brightness_range=(0.5, 0.9)) #←隨機將亮度偏移 0.5~0.9
show(gobj)

gobj = ImageDataGenerator(rescale=1./255,
                          shear_range=50.0)  #←隨機順時針傾斜影像 0~50 度
show(gobj)

gobj = ImageDataGenerator(rescale=1./255,
                          zoom_range=0.3)  #←隨機水平及(或)垂直縮放影像 30% (70%~130%)
show(gobj)

gobj = ImageDataGenerator(rescale=1./255,
                          channel_shift_range=150.0)  #←將隨機選擇通道的像素值偏移 0~150 的幅度
show(gobj)

gobj = ImageDataGenerator(rescale=1./255,
                          horizontal_flip=True, #←隨機水平翻轉影像
                          vertical_flip=True)   #←隨機垂直翻轉影像
show(gobj)

fmode=('nearest', 'reflect', 'wrap', 'constant')
for i in range(4):
    gobj = ImageDataGenerator(rescale=1./255,
                              width_shift_range=0.3,  #←隨機向左或右平移 30% 寬度的像素
                              height_shift_range=90,  #←隨機向上或下平移 90 像素
                              fill_mode=fmode[i], cval=128)
    show(gobj)


def my_fun(img):
    import numpy as np
    x = np.random.randint(img.shape[0]-80) #←隨機取得方塊左上角的 x 位置
    y = np.random.randint(img.shape[1]-80) #←隨機取得方塊左上角的 y 位置
    a = img.copy()           #←將影像複製一份
    a[x:x+80, y:y+80] = 200  #←將 (x,y) 位置的小方塊設為 200 灰階
    return a

gobj = ImageDataGenerator(rescale=1./255,
                          preprocessing_function=my_fun) #←指定自訂的影像變換函式
show(gobj)


