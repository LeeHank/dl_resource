# 載入 MNIST 資料集
from tensorflow.keras.datasets import mnist

(train_images, train_labels), (test_images, test_labels) = mnist.load_data()


# 預處理訓練資料
x_train = train_images.reshape((60000, 28 * 28)) #←將 (60000,28,28) 轉換成 (60000,784)
x_train = x_train.astype('float32') / 255    #←再將 0~255 的像素值轉換成 0~1 的浮點數

x_test = test_images.reshape((10000, 28 * 28))  #}←將 10000 筆測試樣本做同樣的轉換
x_test = x_test.astype('float32') / 255         #}

# 預處理標籤資料
from tensorflow.keras.utils import to_categorical

y_train = to_categorical(train_labels)  #←將標籤做 One-hot 編碼
y_test  = to_categorical(test_labels)  #←將測試做 One-hot 編碼

#程 建立多元分類模型

from tensorflow.keras.models import Sequential  #← 匯入 Keras 的序列式模型類別
from tensorflow.keras.layers import Dense       #← 匯入 Keras 的密集層類別--=

from tensorflow.keras.metrics import MAE
from tensorflow.keras.metrics import MeanAbsoluteError

model = Sequential()                 #← 建立序列模型物件
model.add(Dense(512, activation='relu', input_dim= 784)) #← 加入第一層
model.add(Dense(10, activation='softmax'))               #← 加入第二層
model.compile(  optimizer='rmsprop',                #← 指定優化器
                loss='categorical_crossentropy',    #← 指定損失函數
                metrics=['acc'],                    #← 指定評量準則
              )

# ---- 建立 EarlyStopping Callback 物件 ---- #
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping

early_stopping = EarlyStopping(monitor='val_acc', min_delta=0.01,  patience=0, verbose=1)
model_checkpoint = ModelCheckpoint( filepath='weights.{epoch:02d}-{val_acc:.2f}.h5', 
                                    monitor='val_acc',verbose=1, save_best_only=True)
history = model.fit(x_train, y_train, 
                    epochs=5, batch_size=500,
                    validation_split=0.2,
                    callbacks=[ early_stopping, model_checkpoint ])   # 添加 Callbacks 

# --  繪製準確度與損失值 -- # 
# import util7 as u    	# 匯入自訂的繪圖工具模組

# u.plot( history.history,   # 繪製準確率與驗證準確度的歷史線圖
#         ('acc', 'val_acc'),
#         'Training & Vaildation Acc',
#         ('Epoch','Acc'), )     

# u.plot( history.history,   # 繪製損失與驗證損失的歷史線圖
#         ('loss', 'val_loss'),
#         'Training & Vaildation Loss',
#         ('Epoch','Loss'), ) 