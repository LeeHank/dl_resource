from tensorflow.keras import Input, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, concatenate


# ---- 簡易版的分支 b ---- #

ipt = Input(shape=(10,10,200))    # 輸入
b = Conv2D(128, kernel_size=3, padding='same', activation='relu')(ipt) # 3x3 卷積

model = Model(ipt, b)
model.summary()


# ---- 改良版的分支 b ---- #

b1 = Conv2D(64, kernel_size=1, padding='same', activation='relu')(ipt) # 1x1 卷積
b2 = Conv2D(128, kernel_size=3, padding='same', activation='relu')(b1) # 3x3 卷積

model = Model(ipt, b2)
model.summary()





