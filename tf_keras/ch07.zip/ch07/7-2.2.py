from tensorflow.keras.preprocessing.image import ImageDataGenerator
import util7 as u    #←匯入包含自訂函式的模組

gobj = ImageDataGenerator(rescale=1./255) #←設定要將圖檔的每一個像素值都乘以 1./255

gen = gobj.flow_from_directory(
    'cat_dog/train',         #←指定目標資料夾
    target_size=(150, 150),  #←調整所有影像大小成 150x150
    batch_size=10,           #←每批次要生成多少筆資料
    class_mode='binary')     #←指定分類方式, 這裡是設為二元分類

batch = 0
for data, label in gen:      #←走訪產生器, 每次會產生一批次的樣本及標籤
    print(f'第 {batch} 批次樣本的 shape: {data.shape}, 標籤的 shpae: {label.shape}')
    u.plot_img(data, label)    #←呼叫自訂函式將樣本及標籤畫出來
    batch += 1
    if batch >= 2:  #←滿 2 批次即結束迴圈
        break

print('共可生成', len(gen), '批次的資料')

